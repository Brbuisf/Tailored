# Tailored - AI Digital Closet 👗

![Demo](client/mobile/assets/demo.gif)

## 🛠️ Mac Setup Guide
```bash
# Install dependencies
brew install node python

# Run React Native (iOS)
cd client/mobile
npm install
npx pod-install
npm run ios

FOLDER STRUCTURE
Tailored/
├── client/       # Frontend
├── server/       # Backend + AI
└── datasets/     # Clothing images

GOOGLE_VISION_API_KEY=your_key_here
